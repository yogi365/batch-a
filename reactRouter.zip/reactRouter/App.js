import logo from './logo.svg';
import './App.css';
import ClassComp from './components/classcomp';
import { BrowserRouter,Routes, Route, Link } from 'react-router-dom';
import Home from './components/home';
import About from './components/about';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <BrowserRouter>

          <ul>
            <li>
              <Link to='/'>Home</Link>
            </li>
            <li>
              <Link to='/about'>About Us</Link>
            </li>
            <li>
              <Link to='/comp'>Class Component</Link>
            </li>
          </ul>

          <Routes>
            <Route path='' element={<Home/>}></Route>
            <Route path='about' element={<About/>}/>
            <Route path='comp' element={<ClassComp firstName="Abc"/>}></Route>
          </Routes>
        </BrowserRouter>
      </header>
    </div>
  );
}

export default App;
